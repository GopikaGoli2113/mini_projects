#What is the count of distinct cities in the dataset?1
SELECT COUNT(DISTINCT City) AS distinct_cities_count FROM `amazon (3)`;

#For each branch, what is the corresponding city?2
SELECT DISTINCT Branch, City FROM `amazon (3)`;

#What is the count of distinct product lines in the dataset?3
SELECT COUNT(DISTINCT `Product line`) AS distinct_product_lines_count FROM `amazon (3)`;

#Which payment method occurs most frequently?4
SELECT Payment, COUNT(*) AS count FROM `amazon (3)` 
GROUP BY Payment 
ORDER BY count DESC 
LIMIT 1;

#Which product line has the highest sales?5
SELECT `Product line`, SUM(Total) AS total_sales
FROM `amazon (3)`
GROUP BY `Product line`
ORDER BY total_sales DESC
LIMIT 1;

#How much revenue is generated each month?6
SELECT MONTHNAME(Date) AS Month, SUM(Total) AS Total_Revenue  
FROM `amazon (3)`  
GROUP BY MONTH(Date), MONTHNAME(Date)  
ORDER BY MONTH(Date);

#In which month did the cost of goods sold reach its peak?7
SELECT MONTHNAME(Date) AS Month, SUM(cogs) AS Total_COGS  FROM `amazon (3)`  
GROUP BY MONTH(Date), MONTHNAME(Date)  
ORDER BY Total_COGS DESC  
LIMIT 1;

#Which product line generated the highest revenue?8
SELECT `Product line`, SUM(Total) AS Total_Revenue  FROM `amazon (3)`  
GROUP BY `Product line`  
ORDER BY Total_Revenue DESC  
LIMIT 1;

#In which city was the highest revenue recorded?9
SELECT City, SUM(Total) AS Total_Revenue  FROM `amazon (3)`  
GROUP BY City  
ORDER BY Total_Revenue DESC  
LIMIT 1;

#Which product line incurred the highest Value Added Tax?10
SELECT `Product line`, SUM(`Tax 5%`) AS Total_VAT  FROM `amazon (3)`  
GROUP BY `Product line`  
ORDER BY Total_VAT DESC  
LIMIT 1;

#For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."11
SELECT `Product line`,  SUM(Total) AS Total_Sales,  
       CASE  
           WHEN SUM(Total) > (SELECT AVG(Total) FROM `amazon (3)`) THEN 'Good'  
           ELSE 'Bad'  
       END AS Sales_Performance  
FROM `amazon (3)`  
GROUP BY `Product line`;  

#Identify the branch that exceeded the average number of products sold. 12
SELECT Branch, SUM(Quantity) AS Total_Quantity  FROM `amazon (3)`  
GROUP BY Branch  
HAVING Total_Quantity > (SELECT AVG(Quantity) FROM `amazon (3)`);

#Which product line is most frequently associated with each gender? 13
SELECT Gender, `Product line`, COUNT(*) AS Purchase_Count  FROM `amazon (3)`  
GROUP BY Gender, `Product line`  
HAVING Purchase_Count = (  
    SELECT MAX(Purchase_Count)  
    FROM (  
        SELECT Gender, `Product line`, COUNT(*) AS Purchase_Count  
        FROM `amazon (3)`  
        GROUP BY Gender, `Product line`  
    ) AS subquery  
    WHERE subquery.Gender = `amazon (3)`.Gender  
);

#Calculate the average rating for each product line. 14
SELECT `Product line`, AVG(Rating) AS Average_Rating  FROM `amazon (3)`  
GROUP BY `Product line`;

#Count the sales occurrences for each time of day on every weekday. 15
SELECT DAYNAME(Date) AS Weekday,  
       CASE  
           WHEN HOUR(Time) < 12 THEN 'Morning'  
           WHEN HOUR(Time) < 18 THEN 'Afternoon'  
           ELSE 'Evening'  
       END AS Time_of_Day,  
       COUNT(*) AS Sales_Count  
FROM `amazon (3)`  
GROUP BY Weekday, Time_of_Day  
ORDER BY Weekday;

#Identify the customer type contributing the highest revenue. 16
SELECT `Customer type`, SUM(Total) AS Total_Revenue  FROM `amazon (3)`  
GROUP BY `Customer type`  
ORDER BY Total_Revenue DESC  
LIMIT 1;

#Determine the city with the highest VAT percentage. 17
SELECT City, SUM(`Tax 5%`) AS Total_VAT  FROM `amazon (3)`  
GROUP BY City  
ORDER BY Total_VAT DESC  
LIMIT 1;

#Identify the customer type with the highest VAT payments. 18
SELECT `Customer type`, SUM(`Tax 5%`) AS Total_VAT  FROM `amazon (3)`  
GROUP BY `Customer type`  
ORDER BY Total_VAT DESC  
LIMIT 1;

#What is the count of distinct customer types in the dataset? 19
SELECT COUNT(DISTINCT `Customer type`) AS Count_Distinct_Customer_Types  FROM `amazon (3)`;

#What is the count of distinct payment methods in the dataset? 20
SELECT COUNT(DISTINCT Payment) AS Count_Distinct_Payment_Methods  FROM `amazon (3)`;

#Which customer type occurs most frequently? 21 
SELECT `Customer type`, COUNT(*) AS Count  FROM `amazon (3)`  
GROUP BY `Customer type`  
ORDER BY Count DESC  
LIMIT 1;

#Identify the customer type with the highest purchase frequency. 22
SELECT `Customer type`, COUNT(*) AS Purchase_Frequency  FROM `amazon (3)`  
GROUP BY `Customer type`  
ORDER BY Purchase_Frequency DESC  
LIMIT 1;

#Determine the predominant gender among customers. 23
SELECT Gender, COUNT(*) AS Count  FROM `amazon (3)`  
GROUP BY Gender  
ORDER BY Count DESC  
LIMIT 1;

#Examine the distribution of genders within each branch. 24
SELECT Branch, Gender, COUNT(*) AS Count  FROM `amazon (3)`  
GROUP BY Branch, Gender  
ORDER BY Branch, Count DESC;

#Identify the time of day when customers provide the most ratings. 25
SELECT  
    CASE  
        WHEN HOUR(Time) < 12 THEN 'Morning'  
        WHEN HOUR(Time) < 18 THEN 'Afternoon'  
        ELSE 'Evening'  
    END AS Time_of_Day,  
    COUNT(Rating) AS Rating_Count  
FROM `amazon (3)`  
GROUP BY Time_of_Day  
ORDER BY Rating_Count DESC  
LIMIT 1;

#Determine the time of day with the highest customer ratings for each branch. 26
SELECT Branch,  
       CASE  
           WHEN HOUR(Time) < 12 THEN 'Morning'  
           WHEN HOUR(Time) < 18 THEN 'Afternoon'  
           ELSE 'Evening'  
       END AS Time_of_Day,  
       AVG(Rating) AS Average_Rating  
FROM `amazon (3)`  
GROUP BY Branch, Time_of_Day  
ORDER BY Branch, Average_Rating DESC;

#Identify the day of the week with the highest average ratings. 27
SELECT DAYNAME(Date) AS Day_of_Week,  
       AVG(Rating) AS Average_Rating  
FROM `amazon (3)`  
GROUP BY Day_of_Week  
ORDER BY Average_Rating DESC  
LIMIT 1;

#Determine the day of the week with the highest average ratings for each branch. 28
SELECT Branch,  
       DAYNAME(Date) AS Day_of_Week,  
       AVG(Rating) AS Average_Rating  
FROM `amazon (3)`  
GROUP BY Branch, Day_of_Week  
ORDER BY Branch, Average_Rating DESC;






